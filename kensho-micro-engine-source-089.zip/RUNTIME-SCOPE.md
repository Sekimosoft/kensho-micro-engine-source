# Toolchain/runtime record

NDK 27.1.12297006, Clang18.0.2, Android c++_static. NDK-NOTICE.txt and
toolchain version/source revision information are included unchanged.
This archive includes engine sources, not a full NDK/LLVM source distribution.
Compiler/runtime source references are in toolchain/clang_source_info.md.
Any required corresponding-runtime-source provision or applicable exclusion must
be settled before distributing the engine binary. Publishing this engine-source
archive alone does not certify the complete application's GPL compliance.

## 089 notice/source provenance supplement
NDK-NOTICE.toolchain.txt is now also supplied unchanged from NDK r27b.
Exact compiler base and Android patch URLs are retained in
toolchain/clang_source_info.md; do not substitute an unpinned upstream main.
Base: https://github.com/llvm/llvm-project/tree/3c92011b600bdf70424e2547594dd461fe411a41
Android build/patch revision:
https://android.googlesource.com/toolchain/llvm_android/+/2a4ee244d6dd0dcb8365590b898f7a40ec3cb87a/
This supplements notices and provenance, not the complete runtime source trees.
The scope of corresponding static-runtime sources remains a release decision.
No runtime exclusion or combined-application GPL clearance is asserted.
