# Fixed vc7 runtime source supplement
Complements the engine source-089 archive, not the proprietary Kensho app.
LLVM libc++/ABI/unwind/compiler-rt sources and original Android build scripts,
licenses, provenance, link-input hashes and fixed engine/AAB evidence are included.
No model data, engine executable, key, app source, teaching content or WIP is here.
This source supplement is not a legal clearance for the combined application.
libatomic is a link input; absence of defined generic __atomic_* symbols means
its members are not positively identified as pulled into the executable.
OS bionic libc/libm/libdl and linker64 are device-provided, not copied into AAB.
Android CRT objects are recorded as standard Bionic startup link inputs. Their
System Library classification is documented separately; do not equate them with
the bundled LLVM runtime. Compiler/general build tools are excluded as such.
