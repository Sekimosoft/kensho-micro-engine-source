# Runtime source/build supplement

Exact Android clang/LLVM source revision: d8003a456d14a3deb8054cdaa529ffbf02d9b262 (r522817b/NDK r27b).
Android build scripts revision: 2a4ee244d6dd0dcb8365590b898f7a40ec3cb87a. Archives preserve original licenses.
Unpack each sources/*.tar.gz into llvm-project/<component>/; llvm-cmake maps to
llvm-project/llvm/cmake. Unpack llvm_android separately. See its README.md,
build.py, builders.py and configs.py for official options and Android CMake defines.
Runtime classes include libc++/libc++abi, LibUnwindBuilder and compiler-rt builtins.
Use the Android NDK arm64/API24 target; keep c++_static, libc++abi and hidden NDK
libunwind, not platform-exported unwinder. Existing engine BUILDING.md is unchanged.
The llvm-project compiler/tool source outside these runtime/CMake directories is
not bundled: obtain the same pinned revision if using the full Android toolchain
builder. Compiler/general-purpose build tools are not newly authored app source.
These source snapshots and original build scripts permit inspection/modification;
no runtime or engine rebuild, nor byte-identical runtime reproduction, is claimed.
RUNTIME-EVIDENCE.json pins installed link inputs and matches the symbol-bearing
original to the exact distributed engine by stripping only (not compiling/linking).
Public 089 engine source remains paired with this supplemental runtime archive.
