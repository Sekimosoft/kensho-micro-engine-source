# Toolchain/runtime record

NDK 27.1.12297006, Clang18.0.2, Android c++_static. NDK-NOTICE.txt and
toolchain version/source revision information are included unchanged.
This archive includes engine sources, not a full NDK/LLVM source distribution.
Compiler/runtime source references are in toolchain/clang_source_info.md.
Any required corresponding-runtime-source provision or applicable exclusion must
be settled before distributing the engine binary. Publishing this engine-source
archive alone does not certify the complete application's GPL compliance.
