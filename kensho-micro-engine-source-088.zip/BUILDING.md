Prerequisites: Android NDK r27b 27.1.12297006, CMake3.22.1, Ninja, Python3.
Set NDK to the locally installed NDK path. From this extracted directory:

python engine/source/eval/nnue/architectures/nnue_arch_gen.py SFNN_ka2_2048_8_64_progress8 engine/source/eval/nnue/architectures
cmake -S . -B build -G Ninja -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-24 -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
"$NDK/toolchains/llvm/prebuilt/<host>/bin/llvm-strip" --strip-all -o build/yaneuraou-micro-arm64 build/probe067

Windows may need an explicit -DCMAKE_MAKE_PROGRAM=<SDK CMake>/bin/ninja.exe.
Compiler: Clang18.0.2; PIE, generic NEON, 16KiB page alignment, no embedded model.

Run the CLI from a directory containing the separately licensed nn.bin/progress.bin
model, or set USI EvalDir to that directory. Send usi, isready, position sfen and go
through standard input; responses use standard output. The executable is a PIE,
not a JNI library, even when an Android package gives it a .so filename.
On Android the executable must be installed via the app store's application-code
package in an executable native-library location; do not download executable code.
This source package does not require an upload key, account, Kensho database,
private teaching materials or the proprietary Kensho application to build the CLI.
Reproduction was built in 067; 088 reuses that binary without rebuilding. Toolchain
and absolute build-path differences can change binary bytes; no bit-identical
rebuild result is claimed here.
