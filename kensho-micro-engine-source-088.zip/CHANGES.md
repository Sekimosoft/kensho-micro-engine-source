# Engine build changes — Sekimosoft, 2026-10-29

Base: YaneuraOu 0f421391ae311df9df57dcfcb2b4a78a1972bdf8, original source and per-file copyright notices retained.
067 build changes: generated SFNN_ka2_2048_8_64_progress8 architecture header;
external CMake build listing existing upstream sources; NEON/API24/PIE/16KiB
alignment and c++_static. No Kensho API added to the engine. No model embedded.
088 source publication: reuse 068 source files; replace preview publication/build
instructions with this engine-only publication record and file-hash manifest.
See engine/LICENSE for GPLv3 and individual source files for authorship/notices.
